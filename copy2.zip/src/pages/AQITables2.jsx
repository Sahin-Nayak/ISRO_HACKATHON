import React from 'react';
import AQITable2 from '../components/AQITable2';

const AQITables2 = () => {
    return (
        <div>
            <AQITable2 />
        </div>
    );
};

export default AQITables2;