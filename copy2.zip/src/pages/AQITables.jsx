import React from 'react';
import AQITable1 from '../components/AQITable1';

const AQITables = () => {
    return (
        <div>
            <AQITable1 />
        </div>
    );
};

export default AQITables;